package com.example.app_universidad;

public @interface NonNull {
}
