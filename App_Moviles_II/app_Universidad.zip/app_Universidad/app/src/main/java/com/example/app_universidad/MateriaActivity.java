package com.example.app_universidad;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.Map;

public class MateriaActivity extends AppCompatActivity {

    EditText jetcodmateria, jetnommateria, jetcredmateria, jetnomprofesor;
    CheckBox jcbactivo;

    Button jbtnconsultar, jbtnguardar,jbtncancelar,jbtnactivar,jbtnregresar;
    String codmateria, nommateria, credmateria, nomprofesor, id_materia;
    FirebaseFirestore db = FirebaseFirestore.getInstance();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_materia);
        //ocultar la barra de titulo por defecto
        getSupportActionBar().hide();
        jetcodmateria = findViewById(R.id.etcodmateria);
        jetnommateria = findViewById(R.id.etnommateria);
        jetcredmateria = findViewById(R.id.etcreditos);
        jetnomprofesor=findViewById(R.id.etnomprofesor);
        jcbactivo=findViewById(R.id.cbactivo);
        jbtnguardar=findViewById(R.id.btnguardar);
        jbtnactivar=findViewById(R.id.btnactivar);
        id_materia="";

    }

    public void Consultar(View view){
        Consultardocumento();

    }

    private void Consultardocumento(){
        codmateria=jetcodmateria.getText().toString();
        //Validar que digito un codigo de materia
        if (codmateria.isEmpty()){
            Toast.makeText(this, "Codigo de Materia es Requerido", Toast.LENGTH_SHORT).show();
            jetcodmateria.requestFocus();


        }else{
            jbtnguardar.setEnabled(true);
            jetnommateria.setEnabled(true);
            jetcredmateria.setEnabled(true);
            jetnomprofesor.setEnabled(true);
            jcbactivo.setEnabled(true);
            db.collection("Materias")
                    .whereEqualTo("Codigo Materia",codmateria)
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                for (QueryDocumentSnapshot document : task.getResult()) {
                                    //Log.d(TAG, document.getId() + " => " + document.getData());
                                    id_materia=document.getId();
                                    jetnommateria.setText(document.getString("Nombre Materia"));
                                    jetcredmateria.setText(document.getString("Creditos Materia"));
                                    jetnomprofesor.setText(document.getString("Nombre Profesor"));

                                    if (document.getString("Activo").equals("Si"))
                                        jcbactivo.setChecked(true);
                                    else
                                        jcbactivo.setChecked(false);

                                    jetnommateria.setEnabled(true);
                                    jetcredmateria.setEnabled(true);
                                    jetnomprofesor.setEnabled(true);
                                    jcbactivo.setEnabled(true);

                                }
                            } else {
                                Toast.makeText(MateriaActivity.this, "Codigo de la Materia no Hallado", Toast.LENGTH_SHORT).show();

                            }
                        }
                    });
        }

    }//Fin Consultar Documento

    public  void Adicionar(View view){
        codmateria=jetcodmateria.getText().toString();
        nommateria=jetnommateria.getText().toString();
        credmateria=jetcredmateria.getText().toString();
        nomprofesor=jetnomprofesor.getText().toString();
        //validar que todos los datos fueron ingresados
        if (codmateria.isEmpty() || nommateria.isEmpty() || credmateria.isEmpty() || nomprofesor.isEmpty()){
            Toast.makeText(this, "Todos los Datos son Requeridos", Toast.LENGTH_SHORT).show();
        }else{
            // Create una Nueva Materia
            Map<String, Object> materia = new HashMap<>();
            materia.put("Codigo Materia", codmateria);
            materia.put("Nombre Materia", nommateria);
            materia.put("Creditos Materia", credmateria);
            materia.put("Nombre Profesor", nomprofesor);
            materia.put("Activo", "Si");

            // Add a new document with a generated ID
            db.collection("Materias")
                    .add(materia)
                    .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                        @Override
                        public void onSuccess(DocumentReference documentReference) {
                            // Log.d(TAG, "DocumentSnapshot added with ID: " + documentReference.getId());
                            Limpiar_datos();
                            Toast.makeText(MateriaActivity.this, "Datos Guardados", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            // Log.w(TAG, "Error adding document", e);
                            Toast.makeText(MateriaActivity.this, "Error Guardando Datos", Toast.LENGTH_SHORT).show();
                        }
                    });
        }
    }//fin Adicionar


    public void Modificar(View view){
        if (!id_materia.equals("")){
            codmateria=jetcodmateria.getText().toString();
            nommateria=jetnommateria.getText().toString();
            credmateria=jetcredmateria.getText().toString();
            nomprofesor=jetnomprofesor.getText().toString();
            // Create a new materia
            Map<String, Object> materia = new HashMap<>();
            materia.put("Codigo Materia", codmateria);
            materia.put("Nombre Materia", nommateria);
            materia.put("Creditos Materia", credmateria);
            materia.put("Nombre Profesor", nomprofesor);

            if (jcbactivo.isChecked())
                materia.put("Activo", "Si");
            else
                materia.put("Activo", "No");

            db.collection("Materias").document(id_materia)
                    .set(materia)
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Toast.makeText(MateriaActivity.this,"Materia Actualizada...",Toast.LENGTH_SHORT).show();
                            Limpiar_datos();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(MateriaActivity.this,"Error Actualizando Materia...",Toast.LENGTH_SHORT).show();
                        }
                    });
        }else{
            Toast.makeText(this, "Debe Primero Consultar Para Modificar", Toast.LENGTH_SHORT).show();
            jetcodmateria.requestFocus();
        }
    }//fin Modificar


    public void Cancelar(View view){
        Limpiar_datos();
    }

    public void Regresar(View view){
        Intent intmain = new Intent(this,MainActivity.class);
        startActivity(intmain);
    }


    private void Limpiar_datos(){
        jetcodmateria.setText("");
        jetnommateria.setText("");
        jetcredmateria.setText("");
        jetnomprofesor.setText("");
        jcbactivo.setChecked(false);

        jbtnguardar.setEnabled(false);
        jbtnactivar.setEnabled(false);
        jetnommateria.setEnabled(false);
        jetcredmateria.setEnabled(false);
        jetnomprofesor.setEnabled(false);
        jcbactivo.setEnabled(false);
        jetcodmateria.requestFocus();
    }//Fin Limpiar Datos







}